/**
 * 
 */
/**
 * 
 */
module MysqlJdbcConnectivity {
	requires java.sql;
}