package sqlconnectivity;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

public class DatabaseConnectivity{
	public static void main(String[]args) throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.cj.jdbc.Driver");
	    Connection cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/krce","root","Ranjurp1408@");
	    //Statement stmt=cn.createStatement();
	    String sql="insert into student(name,age,gender,address)values(?,?,?,?)";
	    try {
		
			PreparedStatement pstmt = cn.prepareStatement(sql);
			pstmt.setString(1, "Ranjithapriya");
			pstmt.setInt(2, 21);
			pstmt.setString(3, "female");
			pstmt.setString(4, "adevhiu");
			pstmt.executeUpdate();
			
			pstmt.setString(1, "priya");
			pstmt.setInt(2, 20);
			pstmt.setString(3, "female");
			pstmt.setString(4, "evhiu");
			
			pstmt.executeUpdate();
			
				System.out.println("saved successfully in database");
			//5.close the connection
			}catch(SQLException e){
				System.out.println(e);
	}
	}
}